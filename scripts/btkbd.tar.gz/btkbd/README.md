# btkbd

Gjør laptopen til et ekte Bluetooth-tastatur og mus. Gamingpcen ser den som en
helt vanlig HID-enhet — ingen programvare på mottakersiden, virker også i BIOS
og på maskiner uten nett.

## Avhengigheter

```fish
sudo pacman -S python-dbus python-gobject python-evdev bluez bluez-utils
```

## 1. Konfigurer BlueZ

```fish
sudo ./btkbd.py --setup
```

Den viser nøyaktig hva den vil endre og spør før den gjør det. `setup-bluez.sh`
er bare en wrapper rundt samme kommando.

Oppsettet gjør to ting: deaktiverer `input`-pluginet i `bluetoothd` (som ellers
okkuperer L2CAP-portene 17 og 19 fordi den normalt *tar imot* tastaturer), og
setter Class of Device til `0x0025C0` slik at Windows gjenkjenner deg som
tastatur + pekeenhet.

> Mens dette er aktivt kan ikke laptopen selv bruke Bluetooth-tastatur eller
> -mus. BT-lyd er upåvirket — det er en annen plugin.
> `sudo ./btkbd.py --setup --undo` reverserer alt.

Dette er et separat steg, ikke noe btkbd gjør av seg selv ved oppstart, fordi
det skriver til `/etc` og starter `bluetooth.service` på nytt — en omstart
som kobler ned hodetelefoner og alt annet som er tilkoblet der og da. Det er
en systemendring som lever videre etter at programmet er avsluttet, så den bør
skje når *du* bestemmer det, ikke hver gang du vil skrive noe på en annen
maskin. Har du automatisert oppsettet ditt, tar `--setup --yes` bort
bekreftelsen.

## 2. Start

```fish
sudo ./btkbd.py --list          # se hvilke enheter som plukkes opp
sudo ./btkbd.py --name "Lars laptop"
```

## 3. Par med gamingpcen

Start `btkbd.py` **først** — SDP-posten må være publisert før Windows kan se
deg som tastatur. Så, på gamingpcen: Innstillinger → Bluetooth → Legg til enhet.

Windows viser gjerne en sekssifret kode og ber deg "skrive den på tastaturet".
Den koden skal inn i BlueZ, ikke i lufta. I et annet terminalvindu:

```fish
bluetoothctl
> agent KeyboardOnly
> default-agent
```

Når Windows viser koden, skriver du tallet i `bluetoothctl` og trykker Enter.

Etterpå kan du hoppe over paringen og koble rett opp:

```fish
sudo ./btkbd.py --connect AA:BB:CC:DD:EE:FF
```

## 4. Bruk

Programmet starter i **LOKAL** modus — ingenting videresendes.

**Hold begge shift-tastene i et halvt sekund og slipp** for å veksle mellom
LOKAL og REMOTE. I REMOTE går alt — taster, touchpad, TrackPoint, mus — til
gamingpcen, og ingenting til Niri.

Shift+Shift er valgt fordi det er to rene modifiers: kombinasjonen produserer
ingen tegn og treffer ingen snarvei, verken i Niri eller på gamingpcen, så det
gjør ingenting at den lekker gjennom. Shift fungerer fortsatt som shift.

Selve byttet skjer på *slipp*, ikke når holdetiden er nådd — du får en
«klar»-melding når den er armert. Grunnen er at kompositoren må rekke å se
både trykk og slipp; bytter vi midt i et trykk, blir shift hengende i Niri.

Vil du ha noe annet, tar `--toggle` en hvilken som helst kombinasjon av
evdev-navn:

```fish
sudo ./btkbd.py --toggle KEY_LEFTCTRL+KEY_LEFTALT+KEY_LEFTSHIFT
sudo ./btkbd.py --toggle KEY_RIGHTALT+KEY_LEFTMETA
```

Hold deg til rene modifiers (`KEY_LEFTCTRL`, `KEY_LEFTSHIFT`, `KEY_LEFTALT`,
`KEY_LEFTMETA`, `KEY_RIGHTSHIFT`, `KEY_RIGHTALT`, `KEY_RIGHTMETA`). Bruker du
en vanlig tast, får både Niri og gamingpcen den også — programmet advarer ved
oppstart. `KEY_CAPSLOCK` er teknisk mulig, men da slår caps lock seg på lokalt
hver gang du bytter.

Sikkerhetsnett:

- Overtakelsen skjer bare når ingen taster er nede, så Niri sitter aldri igjen
  med en «hengende» modifier. Holder du en annen tast når du slipper
  kombinasjonen, avbrytes byttet.
- Ved bytte tilbake sendes en tom rapport først, slik at ingen tast blir
  stående nede på gamingpcen.
- Faller Bluetooth-forbindelsen, slippes tastaturet automatisk.
- Ctrl-C eller `systemctl stop` slipper også alltid.
- Verste fall: SSH inn fra mobilen og `sudo pkill -f btkbd`.

## Tastaturlayout

Programmet sender HID-usage-koder, altså *posisjoner*, ikke tegn. Verten
bestemmer layouten. Har gamingpcen norsk layout, får du `ø æ å` der du
forventer. Har den amerikansk, får du `; ' [`. `KEY_102ND` (`<>|`-tasten ved
venstre shift) er med, så den fungerer også.

## Nyttige flagg

| Flagg | Effekt |
|---|---|
| `--device /dev/input/event3` | bruk bare bestemte enheter (kan gjentas) |
| `--toggle KEY_LEFTCTRL+KEY_LEFTALT` | annen vekselkombinasjon |
| `--toggle-hold 1.0` | lengre hold før armering |
| `--touchpad-speed 18` | raskere touchpad |
| `--natural-scroll` | snu scrolleretningen |
| `--no-tap` | skru av tap-to-click |
| `--mouse-rate 200` | flere muserapporter per sekund |
| `--debug` | logg rapportene som faktisk sendes |
| `--selftest` | validerer rapportpakking uten Bluetooth |

## Som tjeneste

```fish
sudo cp btkbd.py /usr/local/bin/btkbd
sudo cp btkbd.service /etc/systemd/system/
sudo systemctl enable --now btkbd
```

Rediger `--connect`-adressen i unit-fila først. Merk at du da mister
statuslinjene i terminalen — `journalctl -fu btkbd` viser dem.

## Feilsøking

**`UUID already registered`** eller **`PSM 17 er opptatt`** — input-pluginet
kjører fortsatt. Begge deler har samme årsak: pluginet eier både HID-UUID-en
og portene. Verifiser med:

```fish
systemctl cat bluetooth | grep ExecStart
pgrep -a bluetoothd
```

Ser du ikke `-P input` i den faktiske kommandolinjen fra `pgrep`, har ikke
drop-in-fila slått inn. Kjør `sudo ./btkbd.py --setup` og
`sudo systemctl restart bluetooth`. Programmet sjekker dette ved oppstart og
sier fra før det prøver seg på D-Bus.

**Windows ser enheten, men som "ukjent"** — Class of Device er ikke satt.
Sjekk `Class` i `/etc/bluetooth/main.conf` og restart `bluetooth`.

**Paret, men ingen forbindelse** — Windows kobler ofte ikke ut av seg selv.
Bruk `--connect <MAC>`, eller klikk på enheten i Windows sin Bluetooth-liste.

**Forbindelsen faller etter noen sekunder** — verten fikk ikke svar på
control-kanalen. Kjør `sudo btmon` i et annet vindu og se hva som sendes rett
før nedkoblingen.

**Pekeren blir værende på laptopen** — sjekk at `sudo ./btkbd.py --list` viser
en linje av typen `touchpad`. Gjør den ikke det, brukes en enhet programmet
ikke kjenner igjen; send utskriften av `sudo libinput list-devices | grep -A2 Kernel`
så utvider jeg gjenkjenningen. `--debug` viser rapportene som faktisk sendes.

**Musen henger etter** — Bluetooth Classic har rundt 7–10 ms latens i praksis.
Godt nok til å skrive og navigere, ikke godt nok til å sikte i Skyrim.
